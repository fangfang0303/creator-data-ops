import argparse
import json
import py_compile
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any


SKILL_ROOT = Path(__file__).resolve().parent.parent
SCRIPT_DIR = SKILL_ROOT / "scripts"

REQUIRED_SCRIPTS = [
    "creator_ops_bridge.py",
    "local_data_store.py",
    "feishu_bridge.py",
    "desktop_backend.py",
    "xhs_monitor.py",
    "douyin_monitor.py",
    "wechat_video_monitor.py",
    "publish_automation.py",
    "run_creator_ops_schedule.ps1",
    "run_all_platforms_fetch.ps1",
]


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def copy_required_scripts(target_root: Path, overwrite: bool) -> dict[str, Any]:
    work_dir = target_root / "work"
    outputs_dir = target_root / "outputs"
    work_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    copied: list[str] = []
    skipped: list[str] = []
    missing_source: list[str] = []
    missing_target: list[str] = []
    compile_failed: list[str] = []

    for name in REQUIRED_SCRIPTS:
        source = SCRIPT_DIR / name
        target = work_dir / name
        if not source.exists():
            missing_source.append(name)
            continue
        if target.exists() and not overwrite:
            skipped.append(name)
        else:
            shutil.copy2(source, target)
            copied.append(name)

    for name in REQUIRED_SCRIPTS:
        target = work_dir / name
        if not target.exists():
            missing_target.append(name)
            continue
        if target.suffix == ".py":
            try:
                py_compile.compile(str(target), doraise=True)
            except Exception as exc:
                compile_failed.append(f"{name}: {exc}")

    result = {
        "ok": not missing_source and not missing_target and not compile_failed,
        "action": "setup_workspace",
        "skill_root": str(SKILL_ROOT),
        "target_root": str(target_root),
        "work_dir": str(work_dir),
        "outputs_dir": str(outputs_dir),
        "copied": copied,
        "skipped": skipped,
        "missing_source": missing_source,
        "missing_target": missing_target,
        "compile_failed": compile_failed,
        "time": now_text(),
    }
    write_json(outputs_dir / "creator_data_ops_setup_result.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", default=".", help="Project root where work/ and outputs/ should live.")
    parser.add_argument("--overwrite", action="store_true", help="Overwrite existing runtime scripts.")
    args = parser.parse_args()

    target_root = Path(args.target).expanduser().resolve()
    result = copy_required_scripts(target_root, overwrite=args.overwrite)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
