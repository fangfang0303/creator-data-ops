import argparse
import csv
import json
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright


WORKDIR = Path(__file__).resolve().parent
OUTPUT_DIR = WORKDIR.parent / "outputs"
STATE_ROOT = WORKDIR / "bilibili_state"
DEFAULT_ACCOUNT = "default"
ACCOUNTS_CONFIG_PATH = WORKDIR / "bilibili_accounts.json"
HOME_URL = "https://member.bilibili.com/platform/home"
ARCHIVES_URL = "https://member.bilibili.com/x/web/archives?status=is_pubed&pn=1&ps=50&coop=1&interactive=1"
NAV_URL = "https://api.bilibili.com/x/web-interface/nav"
RELATION_STAT_URL = "https://api.bilibili.com/x/relation/stat?vmid={mid}"
UPSTAT_URL = "https://api.bilibili.com/x/space/upstat?mid={mid}"
LIVE_ROOM_URL = "https://api.live.bilibili.com/xlive/web-room/v1/index/getInfoByRoom?room_id={room_id}"
EDGE_CANDIDATES = [
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
]


@dataclass
class VideoMetrics:
    fetched_at: str
    item_id: str
    title: str
    publish_time: str
    views: int
    likes: int
    comments: int
    shares: int
    collects: int


def ensure_dirs() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    STATE_ROOT.mkdir(parents=True, exist_ok=True)


def edge_path() -> Path:
    for candidate in EDGE_CANDIDATES:
        if candidate.exists():
            return candidate
    raise RuntimeError("Edge browser not found.")


def normalize_account_name(account: str | None) -> str:
    value = (account or DEFAULT_ACCOUNT).strip() or DEFAULT_ACCOUNT
    return "".join(char if char.isalnum() or char in ("-", "_") else "_" for char in value)


def get_state_dir(account: str) -> Path:
    return STATE_ROOT / normalize_account_name(account)


def get_json_path(account: str) -> Path:
    return OUTPUT_DIR / f"bilibili_metrics_latest_{normalize_account_name(account)}.json"


def get_csv_path(account: str) -> Path:
    return OUTPUT_DIR / f"bilibili_metrics_history_{normalize_account_name(account)}.csv"


def get_screenshot_path(account: str) -> Path:
    return OUTPUT_DIR / f"bilibili_creator_dashboard_{normalize_account_name(account)}.png"


def get_debug_text_path(account: str) -> Path:
    return OUTPUT_DIR / f"bilibili_debug_{normalize_account_name(account)}.txt"


def get_storage_state_path(account: str) -> Path:
    return get_state_dir(account) / "storage_state.json"


def get_login_confirm_path(account: str) -> Path:
    return OUTPUT_DIR / f"bilibili_login_confirm_{normalize_account_name(account)}.flag"


def append_login_trace(account: str, message: str) -> None:
    trace_path = OUTPUT_DIR / f"bilibili_login_trace_{normalize_account_name(account)}.log"
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n"
    try:
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        with trace_path.open("a", encoding="utf-8") as handle:
            handle.write(line)
    except Exception:
        pass


def get_summary_path() -> Path:
    return OUTPUT_DIR / "bilibili_metrics_latest.json"


def ensure_accounts_config() -> None:
    if ACCOUNTS_CONFIG_PATH.exists():
        return
    template = {
        "accounts": [
            {
                "name": DEFAULT_ACCOUNT,
                "enabled": True,
                "login_mode": "manual",
                "notes": "默认哔哩哔哩账号，首次手动登录一次，后续复用登录状态。",
            }
        ]
    }
    ACCOUNTS_CONFIG_PATH.write_text(json.dumps(template, ensure_ascii=False, indent=2), encoding="utf-8-sig")


def load_accounts_config() -> list[dict[str, Any]]:
    ensure_accounts_config()
    data = json.loads(ACCOUNTS_CONFIG_PATH.read_text(encoding="utf-8-sig"))
    accounts = data.get("accounts") or []
    if not isinstance(accounts, list):
        raise RuntimeError("bilibili_accounts.json format is invalid.")

    normalized_accounts: list[dict[str, Any]] = []
    seen: set[str] = set()
    changed = False
    for item in accounts:
        if not isinstance(item, dict):
            changed = True
            continue
        normalized_name = normalize_account_name(str(item.get("name") or ""))
        if normalized_name in seen:
            changed = True
            continue
        seen.add(normalized_name)
        if item.get("name") != normalized_name:
            item["name"] = normalized_name
            changed = True
        normalized_accounts.append(item)
    if changed:
        data["accounts"] = normalized_accounts
        ACCOUNTS_CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8-sig")
    return normalized_accounts


def get_enabled_accounts() -> list[str]:
    names: list[str] = []
    for item in load_accounts_config():
        if not isinstance(item, dict) or item.get("enabled", True) is False:
            continue
        name = normalize_account_name(str(item.get("name") or ""))
        if name:
            names.append(name)
    if not names:
        raise RuntimeError("No enabled Bilibili accounts found.")
    return names


def upsert_account_config(account: str) -> None:
    ensure_accounts_config()
    account_key = normalize_account_name(account)
    raw = json.loads(ACCOUNTS_CONFIG_PATH.read_text(encoding="utf-8-sig"))
    accounts = raw.get("accounts") or []
    if not isinstance(accounts, list):
        accounts = []

    for item in accounts:
        if not isinstance(item, dict):
            continue
        if normalize_account_name(str(item.get("name") or "")) == account_key:
            item["name"] = account_key
            item["enabled"] = True
            item["login_mode"] = item.get("login_mode") or "manual"
            raw["accounts"] = accounts
            ACCOUNTS_CONFIG_PATH.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8-sig")
            return

    accounts.append(
        {
            "name": account_key,
            "enabled": True,
            "login_mode": "manual",
            "notes": "新增账号。首次运行 login 时完成一次手动登录，后续复用登录态。",
        }
    )
    raw["accounts"] = accounts
    ACCOUNTS_CONFIG_PATH.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8-sig")


def request_json(context, url: str) -> dict[str, Any]:
    response = context.request.get(
        url,
        headers={
            "accept": "application/json,text/plain,*/*",
            "referer": HOME_URL,
            "user-agent": "Mozilla/5.0",
        },
        timeout=30000,
    )
    text = response.text()
    try:
        body = json.loads(text)
    except Exception:
        body = {"raw_text": text}
    return {"status": response.status, "body": body}


def response_code(body: dict[str, Any]) -> int:
    try:
        return int(body.get("code", -1))
    except Exception:
        return -1


def bilibili_ok(payload: dict[str, Any]) -> bool:
    body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
    return response_code(body) == 0


def fetch_nav(context) -> dict[str, Any]:
    payload = request_json(context, NAV_URL)
    body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
    data = body.get("data") if isinstance(body.get("data"), dict) else {}
    if response_code(body) != 0 or not data.get("isLogin"):
        raise RuntimeError("Bilibili session is not logged in.")
    return data


def is_login_complete(page) -> bool:
    try:
        fetch_nav(page.context)
        return True
    except Exception:
        pass
    try:
        body_text = page.locator("body").inner_text(timeout=8000)
    except Exception:
        body_text = ""
    if any(marker in body_text for marker in ["登录", "扫码登录", "密码登录", "立即登录"]):
        return False
    return "创作中心" in body_text and "稿件" in body_text


def wait_for_manual_login(page, account: str) -> None:
    page.goto(HOME_URL, wait_until="domcontentloaded", timeout=60000)
    print("Browser opened. Complete the Bilibili Creator login manually.")
    print("After login finishes, keep this browser window open and reply login complete in Codex.")

    confirm_path = get_login_confirm_path(account)
    append_login_trace(account, f"session:wait_for_user_confirm path={confirm_path}")
    deadline = time.time() + 600
    while time.time() < deadline:
        if confirm_path.exists():
            append_login_trace(account, "session:user_confirmed")
            return
        time.sleep(1)

    raise RuntimeError("Bilibili login confirmation timed out.")


def to_int(value: Any) -> int:
    if value in (None, "", "--"):
        return 0
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip().replace(",", "")
    try:
        if text.lower().endswith("w") or text.endswith("万"):
            return int(float(text[:-1]) * 10000)
        return int(float(text))
    except Exception:
        return 0


def format_time(value: Any) -> str:
    if value in (None, ""):
        return ""
    try:
        timestamp = int(value)
        if timestamp > 100000000000:
            timestamp = timestamp // 1000
        if timestamp > 1000000000:
            return datetime.fromtimestamp(timestamp).isoformat(timespec="seconds")
    except Exception:
        pass
    return str(value)


def first_value(data: dict[str, Any], keys: list[str]) -> Any:
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    return ""


def nested_candidates(item: dict[str, Any]) -> list[dict[str, Any]]:
    candidates = [item]
    for key in ["archive", "Archive", "arc", "video", "item"]:
        value = item.get(key)
        if isinstance(value, dict):
            candidates.insert(0, value)
    return candidates


def value_from_candidates(item: dict[str, Any], keys: list[str]) -> Any:
    for candidate in nested_candidates(item):
        value = first_value(candidate, keys)
        if value not in (None, ""):
            return value
    return ""


def stat_from_item(item: dict[str, Any]) -> dict[str, Any]:
    for candidate in nested_candidates(item):
        stat = candidate.get("stat")
        if isinstance(stat, dict):
            return stat
    return {}


def looks_like_video_item(item: dict[str, Any]) -> bool:
    video_keys = {"aid", "bvid", "archive_id", "title", "ptime", "pubtime", "publish_time", "ctime", "stat"}
    if any(key in item for key in video_keys):
        return True
    for key in ["archive", "Archive", "arc", "video", "item"]:
        value = item.get(key)
        if isinstance(value, dict) and any(field in value for field in video_keys):
            return True
    return False


def video_items(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict) and looks_like_video_item(item)]


def extract_archive_items(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, list):
        return video_items(data)
    if not isinstance(data, dict):
        return []

    keys = ["arc_audits", "archives", "items", "list", "vlist", "results"]
    for key in keys:
        value = data.get(key)
        if isinstance(value, list):
            items = video_items(value)
            if items:
                return items
        if isinstance(value, dict):
            nested = extract_archive_items(value)
            if nested:
                return nested

    ignored_list_keys = {"type", "class", "tip", "rich_tip", "copyright_banner", "play_type"}
    for key, value in data.items():
        if key in ignored_list_keys:
            continue
        if isinstance(value, (list, dict)):
            nested = extract_archive_items(value)
            if nested:
                return nested
    return []


def parse_videos(payload: dict[str, Any]) -> tuple[list[VideoMetrics], dict[str, Any]]:
    body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
    data = body.get("data") if isinstance(body.get("data"), dict) else {}
    items = extract_archive_items(data)
    fetched_at = datetime.now().isoformat(timespec="seconds")
    videos: list[VideoMetrics] = []

    for index, item in enumerate(items, start=1):
        stat = stat_from_item(item)
        aid = value_from_candidates(item, ["aid", "id", "archive_id"])
        bvid = value_from_candidates(item, ["bvid", "bv_id"])
        item_id = str(bvid or aid or f"video-{index}")
        title = str(value_from_candidates(item, ["title", "desc", "description"]) or "")
        publish_time = format_time(value_from_candidates(item, ["ptime", "pubtime", "publish_time", "ctime", "created_at"]))
        videos.append(
            VideoMetrics(
                fetched_at=fetched_at,
                item_id=item_id,
                title=title,
                publish_time=publish_time,
                views=to_int(first_value(stat, ["view", "play", "views"]) or value_from_candidates(item, ["view", "play", "views"])),
                likes=to_int(first_value(stat, ["like", "likes"]) or value_from_candidates(item, ["like", "likes"])),
                comments=to_int(first_value(stat, ["reply", "comment", "comments"]) or value_from_candidates(item, ["reply", "comment", "comments"])),
                shares=to_int(first_value(stat, ["share", "shares"]) or value_from_candidates(item, ["share", "shares"])),
                collects=to_int(first_value(stat, ["favorite", "collect", "collects"]) or value_from_candidates(item, ["favorite", "collect", "collects"])),
            )
        )

    videos.sort(key=lambda item: item.publish_time or "", reverse=True)
    return videos, {"archive_response_code": body.get("code"), "archive_raw_total": len(items)}


def build_profile(context, nav_data: dict[str, Any], video_count: int) -> dict[str, Any]:
    mid = str(nav_data.get("mid") or "")
    profile = {
        "name": str(nav_data.get("uname") or nav_data.get("name") or ""),
        "mid": mid,
        "account_id": mid,
        "follow_count": "",
        "fans_count": "",
        "liked_count": "",
        "archive_view_count": "",
        "works_count": video_count,
    }

    if mid:
        relation = request_json(context, RELATION_STAT_URL.format(mid=mid))
        if bilibili_ok(relation):
            data = relation.get("body", {}).get("data", {})
            if isinstance(data, dict):
                profile["follow_count"] = to_int(data.get("following"))
                profile["fans_count"] = to_int(data.get("follower"))

        upstat = request_json(context, UPSTAT_URL.format(mid=mid))
        if bilibili_ok(upstat):
            data = upstat.get("body", {}).get("data", {})
            if isinstance(data, dict):
                profile["liked_count"] = to_int(data.get("likes"))
                archive = data.get("archive") if isinstance(data.get("archive"), dict) else {}
                profile["archive_view_count"] = to_int(archive.get("view"))

    return profile


def build_live_metrics(context, nav_data: dict[str, Any]) -> dict[str, Any]:
    live_room = nav_data.get("live_room") if isinstance(nav_data.get("live_room"), dict) else {}
    room_id = live_room.get("roomid") or live_room.get("room_id")
    if not room_id:
        return {}

    payload = request_json(context, LIVE_ROOM_URL.format(room_id=room_id))
    body = payload.get("body") if isinstance(payload.get("body"), dict) else {}
    data = body.get("data") if isinstance(body.get("data"), dict) else {}
    room_info = data.get("room_info") if isinstance(data.get("room_info"), dict) else {}
    watched_show = data.get("watched_show") if isinstance(data.get("watched_show"), dict) else {}
    return {
        "overview": {
            "has_live_data": bool(room_info),
            "room_count": 1 if room_info else 0,
            "live_watch_count": to_int(watched_show.get("num") or watched_show.get("text_large") or watched_show.get("text_small")),
            "room_id": str(room_id),
            "live_status": str(room_info.get("live_status") or ""),
            "title": str(room_info.get("title") or ""),
        },
        "room_info": room_info,
        "watched_show": watched_show,
    }


def save_results(
    videos: list[VideoMetrics],
    profile: dict[str, Any],
    dashboard: dict[str, Any],
    live: dict[str, Any],
    account: str,
) -> dict[str, Any]:
    payload = {
        "fetched_at": datetime.now().isoformat(timespec="seconds"),
        "account_key": normalize_account_name(account),
        "account": profile,
        "dashboard_metrics": dashboard,
        "live": live,
        "videos_count": len(videos),
        "latest_video": asdict(videos[0]) if videos else None,
        "all_videos": [asdict(item) for item in videos],
    }
    get_json_path(account).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8-sig")

    csv_path = get_csv_path(account)
    file_exists = csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "fetched_at",
                "item_id",
                "title",
                "publish_time",
                "views",
                "likes",
                "comments",
                "shares",
                "collects",
            ],
        )
        if not file_exists:
            writer.writeheader()
        for item in videos:
            writer.writerow(asdict(item))
    return payload


def update_summary_file() -> None:
    payloads_by_account: dict[str, dict[str, Any]] = {}
    for path in sorted(OUTPUT_DIR.glob("bilibili_metrics_latest_*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        account_key = normalize_account_name(str(payload.get("account_key") or path.stem.replace("bilibili_metrics_latest_", "")))
        payload["account_key"] = account_key
        previous = payloads_by_account.get(account_key)
        if previous is None or str(payload.get("fetched_at") or "") >= str(previous.get("fetched_at") or ""):
            payloads_by_account[account_key] = payload

    payloads = list(payloads_by_account.values())
    summary = {
        "fetched_at": datetime.now().isoformat(timespec="seconds"),
        "accounts_count": len(payloads),
        "accounts": payloads,
    }
    get_summary_path().write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8-sig")


def run_login(account: str) -> None:
    ensure_dirs()
    ensure_accounts_config()
    account_key = normalize_account_name(account)
    state_dir = get_state_dir(account_key)
    state_dir.mkdir(parents=True, exist_ok=True)
    storage_state_path = state_dir / "storage_state.json"
    append_login_trace(account_key, "run_login:start")

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(state_dir),
            executable_path=str(edge_path()),
            headless=False,
        )
        page = context.pages[0] if context.pages else context.new_page()
        append_login_trace(account_key, f"page:open_home:{HOME_URL}")
        wait_for_manual_login(page, account_key)
        page.goto(HOME_URL, wait_until="domcontentloaded", timeout=60000)
        page.wait_for_timeout(5000)
        if not is_login_complete(page):
            append_login_trace(account_key, "session:confirm_received_but_page_not_ready")
            raise RuntimeError("Current page is not the Bilibili creator dashboard.")
        context.storage_state(path=str(storage_state_path))
        upsert_account_config(account_key)
        append_login_trace(account_key, f"storage:saved path={storage_state_path}")
        print(f"Bilibili login state saved for account: {account_key}")
        context.close()


def run_fetch(account: str) -> None:
    ensure_dirs()
    account_key = normalize_account_name(account)
    state_dir = get_state_dir(account_key)
    screenshot_path = get_screenshot_path(account_key)

    with sync_playwright() as playwright:
        context = playwright.chromium.launch_persistent_context(
            user_data_dir=str(state_dir),
            executable_path=str(edge_path()),
            headless=True,
        )
        page = context.pages[0] if context.pages else context.new_page()
        try:
            page.goto(HOME_URL, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(4000)
            nav_data = fetch_nav(context)
            archive_payload = request_json(context, ARCHIVES_URL)
            videos, archive_meta = parse_videos(archive_payload)
            profile = build_profile(context, nav_data, len(videos))
            live = build_live_metrics(context, nav_data)
            dashboard = {
                "home_url": HOME_URL,
                "archive_meta": archive_meta,
                "archive_status": archive_payload.get("status"),
            }
            save_results(videos, profile, dashboard, live, account_key)
            update_summary_file()
            try:
                page.screenshot(path=str(screenshot_path), full_page=True, timeout=15000)
            except Exception:
                pass
            latest_title = videos[0].title if videos else "No published works found"
            print(
                f"Bilibili fetch complete for {account_key}. "
                f"Total videos: {len(videos)}. Latest video: {latest_title}"
            )
        except Exception:
            try:
                page.screenshot(path=str(screenshot_path), full_page=True)
            except Exception:
                pass
            try:
                body_text = page.locator("body").inner_text(timeout=10000)
                get_debug_text_path(account_key).write_text(body_text, encoding="utf-8-sig")
            except Exception:
                pass
            raise
        finally:
            context.close()


def run_fetch_all() -> None:
    errors: list[str] = []
    for account in get_enabled_accounts():
        try:
            run_fetch(account)
        except Exception as exc:
            errors.append(f"{account}: {exc}")
    if errors:
        raise RuntimeError(" | ".join(errors))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["login", "fetch", "fetch-all"])
    parser.add_argument("--account", default=DEFAULT_ACCOUNT)
    args = parser.parse_args()

    try:
        if args.mode == "login":
            run_login(args.account)
        elif args.mode == "fetch":
            run_fetch(args.account)
        else:
            run_fetch_all()
        return 0
    except PlaywrightTimeoutError as exc:
        print(f"Page wait timed out: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
