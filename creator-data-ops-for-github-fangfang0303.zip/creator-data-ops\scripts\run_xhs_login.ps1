﻿$ErrorActionPreference = "Stop"

function Get-PythonCommand {
    $preferred = @(
        "C:\Users\surface\anaconda3\python.exe"
    )

    foreach ($candidate in $preferred) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    $fallback = @(
        "python",
        "py"
    )

    foreach ($candidate in $fallback) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) {
            return $candidate
        }
    }

    throw "Python not found. Install Python first, then make sure python or py works in terminal."
}

$python = Get-PythonCommand
$script = Join-Path $PSScriptRoot "xhs_monitor.py"
$account = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "" }

if (-not $account) {
    Add-Type -AssemblyName Microsoft.VisualBasic
    $account = [Microsoft.VisualBasic.Interaction]::InputBox(
        "Please enter an account alias, for example xhs2 or brand1",
        "Add Xiaohongshu Account",
        "xhs2"
    )
}

if (-not $account) {
    throw "Account name is required."
}

& $python $script login --account $account
