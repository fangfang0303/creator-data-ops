---
name: creator-data-ops
description: Manage creator-platform account data for Xiaohongshu, Douyin, WeChat Channels, and Bilibili through a dialogue-first workflow. Use when the user wants to install or use a social media operations skill, initialize data storage on the computer or Feishu, add platform accounts, confirm login, manually fetch all platform data, set scheduled fetch time, or sync account/content/live data into local CSV files or Feishu tables.
---

# Creator Data Ops

## Important Encoding Rule

Keep this main skill file mostly ASCII to avoid mojibake on Windows machines that read Markdown with the system default code page.

For Chinese user-facing wording and product details, read:

1. `references/dialogue-guide.txt`
2. `references/workflow-spec.md`
3. `references/project-goal.txt`

If Chinese text displays as garbled characters, re-read the reference files with UTF-8 or UTF-8-SIG.

## Core Goal

Use a dialogue-first workflow to help non-technical users manage creator accounts on Xiaohongshu, Douyin, WeChat Channels, and Bilibili.

Keep the product direction aligned with:

1. Dialogue is the operation entry.
2. The local executor opens login pages, saves login state, fetches data, and runs schedules.
3. Data is displayed or stored in local computer files or Feishu, depending on the user's choice.
4. Feishu is only a display and sync layer, not the trigger for login or fetch actions.

## First-Run Flow

When the user says they installed this skill, asks to start using it, or needs setup:

1. Prepare the workspace by running the bundled setup script.
2. Briefly explain what the skill does.
3. Explain the basic commands for adding accounts, manual fetch, scheduled fetch, and schedule changes.
4. Ask whether data should be stored on the computer or in Feishu.

Use Chinese wording from `references/dialogue-guide.txt` when replying to end users.

## Workspace Setup

Before running the dialogue bridge in a new project, always run:

```powershell
python "<skill-dir>\scripts\setup_workspace.py" --target "<project-root>" --overwrite
```

This script must create:

1. `<project-root>\work`
2. `<project-root>\outputs`

It must copy and verify these required runtime files:

1. `creator_ops_bridge.py`
2. `local_data_store.py`
3. `feishu_bridge.py`
4. `desktop_backend.py`
5. `xhs_monitor.py`
6. `douyin_monitor.py`
7. `wechat_video_monitor.py`
8. `bilibili_monitor.py`
9. `publish_automation.py`
10. `run_creator_ops_schedule.ps1`
11. `run_all_platforms_fetch.ps1`
12. `run_xhs_login.ps1`
13. `run_xhs_fetch.ps1`
14. `run_xhs_fetch_all.ps1`
15. `run_douyin_login.ps1`
16. `run_douyin_fetch.ps1`
17. `run_douyin_fetch_all.ps1`
18. `run_wechat_video_login.ps1`
19. `run_wechat_video_fetch.ps1`
20. `run_wechat_video_fetch_all.ps1`
21. `run_bilibili_login.ps1`
22. `run_bilibili_fetch.ps1`
23. `run_bilibili_fetch_all.ps1`

If setup reports `missing_source`, `missing_target`, or `compile_failed`, fix that before continuing. Do not proceed with partial runtime files.

The setup result is written to:

```text
<project-root>\outputs\creator_data_ops_setup_result.json
```

## Normal Dialogue Command

After setup, route user instructions through:

```powershell
python "work\creator_ops_bridge.py" chat --text "<user text>"
```

Supported examples:

1. Start setup conversation: use the Chinese phrase in `dialogue-guide.txt` for "start using".
2. Choose local computer storage.
3. Choose Feishu storage.
4. Add Xiaohongshu account.
5. Add Douyin account.
6. Add WeChat Channels account.
7. Add Bilibili account.
8. Confirm login complete.
9. Fetch all platform data.
10. Fetch one platform.
11. Fetch one account.
12. View status.
13. Change scheduled fetch time.

## Storage Choice

### Computer Storage

If the user chooses computer storage:

1. Run the dialogue bridge with the user's storage choice.
2. Create a local data folder.
3. Create account-data CSV and content-live-data CSV.
4. Tell the user the exact file paths and what each file stores.
5. Guide the user to add a platform account.

### Feishu Storage

If the user chooses Feishu storage:

1. Use `lark-shared`, `lark-base`, and related lark skills as needed.
2. Check or install lark-cli.
3. Start Feishu user authorization with split-flow.
4. Show the authorization URL and QR code.
5. Tell the user the authorization is only used to sync account, content, and live data into Feishu.
6. Stop and wait for the user to say authorization is complete.
7. Finalize auth and create or sync the Feishu knowledge base and tables.

## Fetch And Sync Rules

Do not sync temporary placeholder accounts during the add-account step.

Login-window close rule:

1. When adding an account, tell the user to finish login in the opened browser window.
2. Tell the user not to close that browser window before replying login complete.
3. After the user confirms login complete, signal the local login process to save the login state.
4. Only after the login state has been saved should the browser window be closed or the first fetch start.
5. If the browser window still blocks the first fetch, then ask the user to close it and confirm login complete again.

Only sync an account to the selected display/storage layer after:

1. The platform login window opened successfully.
2. The user confirmed login completion.
3. The first real fetch completed.
4. A metrics file exists with a non-empty `account` object.

If the login window fails to open, clean up the temporary account config and pending record. Tell the user the temporary account was not synced.

After successful login confirmation:

1. Save login state.
2. Run the first fetch for that account.
3. Extract real account name and account ID if possible.
4. Sync account data and content/live data to the selected storage layer.
5. Tell the user the default scheduled fetch time.

After manual fetch or scheduled fetch:

1. Fetch all selected accounts.
2. Keep successful, failed, and skipped counts.
3. Sync latest rows to the selected storage layer.
4. Tell the user where to view data.

If Feishu already contains old placeholder rows such as `xhs_pending_1`, route the user command for cleaning placeholder accounts to the dialogue bridge. It should delete only records that are not fetched, have no latest fetch time, and still use a `_pending_` account marker as the account name.

## Scheduled Task Rules

Default schedule: daily at 00:00.

Scheduled fetch must run through the user's local Windows Task Scheduler, not through a new daily Codex conversation.

When setting or changing a schedule:

1. Create or update a local scheduled task on the user's computer.
2. The scheduled task should call the bundled local runner script directly.
3. It should fetch data in the background and sync to the selected storage layer.
4. Do not create recurring Codex reminders, automations, wakeups, or new conversations for daily data fetch.
5. Only use Codex dialogue when the user actively asks to add accounts, manually fetch, view status, or change the schedule.

When the user asks to change scheduled time, do not assume the scope. Ask whether it applies to:

1. All platforms and all accounts.
2. One platform and all accounts.
3. One specific account under one platform.

Only update the schedule after both time and scope are clear.

## Guardrails

1. Keep user-facing explanations non-technical.
2. Do not ask users to run scripts manually unless there is no better option.
3. Do not store user passwords.
4. Do not treat Feishu as the login trigger layer.
5. If a platform login page is already logged into the wrong account, guide the user to log out or switch account in that browser, then complete login.
6. If a command fails, explain the next user action in one short sentence and preserve local state.
