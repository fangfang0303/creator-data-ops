﻿# creator-data-ops

这是一个 Codex skill，用于通过对话管理小红书、抖音、微信视频号账号数据。

## 能做什么

1. 新增平台账号：小红书、抖音、微信视频号。
2. 登录完成后自动保存登录状态。
3. 抓取账号数据、笔记/作品数据、直播数据。
4. 支持手动抓取所有平台数据。
5. 支持每天定时抓取，默认每天 24 点（00:00）。
6. 支持把数据存到电脑本地 CSV 文件，或同步到飞书知识库。

## 给用户的安装方式

用户在 Codex 里说：

```text
安装这个 skill：https://github.com/fangfang0303/creator-data-ops/tree/main/creator-data-ops
```

安装完成后，用户需要重启 Codex，让新 skill 生效。

## 你怎么上传到 GitHub

你的 GitHub 用户名是 `fangfang0303`，仓库名是 `creator-data-ops`。

上传时，把当前这个文件夹里的内容上传到仓库根目录。也就是 GitHub 仓库里应该长这样：

```text
README.md
.gitignore
creator-data-ops/
```

不要再额外套一层 `creator-data-ops-github/` 文件夹。

## 安装后怎么开始

用户重启 Codex 后，可以说：

```text
使用 creator-data-ops 开始使用
```

Codex 会先说明这个 skill 是干嘛的，然后询问：

```text
你的数据想存在哪里？请回复：电脑 或 飞书。
```

## 如果初始化时脚本没有复制完整

让 Codex 执行 skill 里的初始化脚本，把运行文件一次性复制到当前项目：

```text
请使用 creator-data-ops 的 setup_workspace.py 初始化当前项目
```

这个初始化会创建：

```text
work/
outputs/
```

并校验这些关键文件是否存在：

```text
creator_ops_bridge.py
desktop_backend.py
publish_automation.py
xhs_monitor.py
douyin_monitor.py
wechat_video_monitor.py
local_data_store.py
feishu_bridge.py
```

如果缺文件，会在 `outputs/creator_data_ops_setup_result.json` 里写明具体缺哪个。

## 如果飞书里出现 xhs_pending_1 这类临时账号

新版已经修复：新增账号阶段不会再把临时占位账号同步到飞书；只有登录成功并完成首次抓数后，才会写入飞书。

如果你之前已经出现过 `xhs_pending_1`、`douyin_pending_1` 这类未抓取占位账号，可以让 Codex 执行：

```text
清理飞书占位账号
```

系统会只清理“未抓取、没有最近拉数时间、账号名等于 pending 标识”的临时记录，不会删除已经抓到数据的真实账号。

## 常用话术

```text
新增小红书
新增抖音
新增微信视频号
登录完成
抓取所有平台数据
定时改成 09:00
查看状态
```

## 新增账号时的登录窗口不要先关

用户新增平台账号后，Codex 会打开平台登录窗口。

正确操作是：

```text
1. 在打开的浏览器窗口里完成登录。
2. 看到已经进入平台后台后，不要先关闭浏览器窗口。
3. 回到 Codex 回复：登录完成。
4. Codex 保存登录态并继续首次抓数。
5. 如果系统提示浏览器窗口仍占用，再按提示关闭窗口并回复一次登录完成。
```

不要在回复登录完成之前先关闭浏览器窗口，否则可能出现登录态没保存或首次抓数失败。

## 目录说明

```text
creator-data-ops/
  SKILL.md
  agents/openai.yaml
  scripts/
  references/
```

## 注意

这个 skill 不保存用户密码。平台登录通过浏览器完成，登录态保存在用户自己的电脑本地。
