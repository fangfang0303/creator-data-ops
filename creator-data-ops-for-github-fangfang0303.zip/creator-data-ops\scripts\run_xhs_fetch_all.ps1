$ErrorActionPreference = "Stop"

$script = Join-Path $PSScriptRoot "xhs_monitor.py"

function Get-PythonCommand {
    $candidates = @(
        "python",
        "py"
    )

    foreach ($candidate in $candidates) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) {
            return $candidate
        }
    }

    throw "找不到可用的 Python。请先安装 Python，并确保命令行里可以运行 python 或 py。"
}

$python = Get-PythonCommand

& $python $script fetch-all
