﻿$ErrorActionPreference = "Stop"

function Get-PythonCommand {
    $preferred = @(
        "C:\Users\surface\anaconda3\python.exe"
    )

    foreach ($candidate in $preferred) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    $fallback = @(
        "python",
        "py"
    )

    foreach ($candidate in $fallback) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) {
            return $candidate
        }
    }

    throw "找不到可用的 Python。请先安装 Python，并确保命令行里可以运行 python 或 py。"
}

$python = Get-PythonCommand
$script = Join-Path $PSScriptRoot "douyin_monitor.py"
$account = if ($args.Count -gt 0 -and $args[0]) { $args[0] } else { "default" }

& $python $script fetch --account $account
