import argparse
import json
from pathlib import Path

from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

import douyin_monitor
import wechat_video_monitor
import xhs_monitor


ROOT = Path(__file__).resolve().parent.parent
EDGE_PATH = Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe")
OUTPUTS = ROOT / "outputs"


def write_debug(name: str, payload: dict) -> None:
    (OUTPUTS / name).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8-sig",
    )


def normalize_asset_paths(asset_paths: list[str]) -> list[str]:
    items: list[str] = []
    for raw in asset_paths:
        value = str(raw).strip().strip('"')
        if not value:
            continue
        items.append(str(Path(value).expanduser()))
    return items


def build_task_payload(
    platform: str,
    account: str,
    content_type: str,
    title: str,
    body: str,
    asset_paths: list[str],
    task_id: str,
) -> dict:
    return {
        "task_id": task_id,
        "platform": platform,
        "account": account,
        "content_type": content_type,
        "title": title,
        "body": body,
        "asset_paths": normalize_asset_paths(asset_paths),
    }


def write_publish_brief(task: dict) -> Path:
    task_id = str(task.get("task_id") or "unknown")
    account = str(task.get("account") or "")
    platform = str(task.get("platform") or "")
    brief_path = OUTPUTS / f"publish_brief_{task_id}_{platform}_{account}.txt"
    lines = [
        "统一发布任务",
        f"任务ID：{task_id}",
        f"平台：{platform}",
        f"账号：{account}",
        f"内容类型：{task.get('content_type') or ''}",
        f"标题：{task.get('title') or ''}",
        f"正文：{task.get('body') or ''}",
        "",
        "素材文件：",
    ]
    assets = task.get("asset_paths") or []
    if assets:
        lines.extend([f"- {item}" for item in assets])
    else:
        lines.append("- 无")
    lines.extend(
        [
            "",
            "当前版本说明：",
            "1. 系统会自动打开对应平台的已登录发布窗口。",
            "2. 系统会把本次任务信息写到页面里，也会生成这份本地说明文件。",
            "3. 你只需要在打开的浏览器里继续上传素材、确认标题正文、最后点击发布。",
        ]
    )
    brief_path.write_text("\n".join(lines), encoding="utf-8-sig")
    return brief_path


def attach_task_to_page(page, task: dict, brief_path: Path) -> None:
    page.evaluate(
        """
([task, briefPath]) => {
  window.__codexPublishTask = task;
  window.__codexPublishBriefPath = briefPath;
}
""",
        [task, str(brief_path)],
    )


def open_best_effort(page, urls: list[str]) -> None:
    last_error = None
    for url in urls:
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(3000)
            return
        except Exception as exc:  # pragma: no cover
            last_error = exc
    if last_error:
        raise last_error


def maybe_click_by_text(page, candidates: list[str]) -> str:
    for text in candidates:
        try:
            locator = page.get_by_text(text, exact=False).first
            if locator.count() == 0:
                continue
            locator.click(timeout=3000)
            page.wait_for_timeout(2500)
            return text
        except Exception:
            continue
    return ""


def maybe_click_selector(page, selectors: list[str]) -> str:
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            locator.wait_for(state="visible", timeout=3000)
            locator.click(timeout=3000)
            page.wait_for_timeout(2500)
            return selector
        except Exception:
            continue
    return ""


def open_xhs(
    account: str,
    content_type: str,
    title: str,
    body: str,
    asset_paths: list[str],
    task_id: str,
) -> None:
    task = build_task_payload("xhs", account, content_type, title, body, asset_paths, task_id)
    brief_path = write_publish_brief(task)
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(xhs_monitor.get_state_dir(account)),
            executable_path=str(EDGE_PATH),
            headless=False,
        )
        page = context.pages[0] if context.pages else context.new_page()
        urls = [
            "https://creator.xiaohongshu.com/publish/publish?source=official",
            "https://creator.xiaohongshu.com/new/home?roleType=creator",
            xhs_monitor.HOME_URL,
        ]
        open_best_effort(page, urls)
        clicked = ""
        if "publish" not in page.url.lower():
            clicked = maybe_click_by_text(page, ["发布图文笔记", "发布视频笔记", "发布笔记"])
        if content_type == "image":
            clicked = clicked or maybe_click_selector(
                page,
                [
                    "text=上传图文",
                    "button:has-text('上传图文')",
                    "[class*='tab']:has-text('上传图文')",
                ],
            )
        else:
            clicked = clicked or maybe_click_selector(
                page,
                [
                    ".upload-button",
                    "button.custom-button",
                    "button:has-text('上传视频')",
                ],
            )
        attach_task_to_page(page, task, brief_path)
        write_debug(
            f"publish_open_xhs_{account}.json",
            {
                "platform": "xhs",
                "account": account,
                "content_type": content_type,
                "title": title,
                "body": body,
                "asset_paths": task["asset_paths"],
                "task_id": task_id,
                "url": page.url,
                "clicked_entry": clicked,
                "brief_path": str(brief_path),
                "status": "opened",
            },
        )
        print(f"XHS publish window opened for {account}.")
        page.wait_for_timeout(1000 * 60 * 30)


def open_douyin(
    account: str,
    content_type: str,
    title: str,
    body: str,
    asset_paths: list[str],
    task_id: str,
) -> None:
    task = build_task_payload("douyin", account, content_type, title, body, asset_paths, task_id)
    brief_path = write_publish_brief(task)
    with sync_playwright() as p:
        state_dir = douyin_monitor.repair_state_dir_aliases(account)
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(state_dir),
            executable_path=str(EDGE_PATH),
            headless=False,
        )
        page = context.pages[0] if context.pages else context.new_page()
        urls = [
            "https://creator.douyin.com/creator-micro/content/upload",
            "https://creator.douyin.com/creator-micro/content/posting?enter_from=publish_page",
            douyin_monitor.HOME_URL,
        ]
        open_best_effort(page, urls)
        clicked = ""
        if "upload" not in page.url.lower() and "posting" not in page.url.lower():
            clicked = maybe_click_by_text(page, ["高清发布", "发布视频", "发布图文"])
        attach_task_to_page(page, task, brief_path)
        write_debug(
            f"publish_open_douyin_{account}.json",
            {
                "platform": "douyin",
                "account": account,
                "content_type": content_type,
                "title": title,
                "body": body,
                "asset_paths": task["asset_paths"],
                "task_id": task_id,
                "url": page.url,
                "clicked_entry": clicked,
                "brief_path": str(brief_path),
                "status": "opened",
            },
        )
        print(f"Douyin publish window opened for {account}.")
        page.wait_for_timeout(1000 * 60 * 30)


def open_wechat_video(
    account: str,
    content_type: str,
    title: str,
    body: str,
    asset_paths: list[str],
    task_id: str,
) -> None:
    task = build_task_payload("wechat_video", account, content_type, title, body, asset_paths, task_id)
    brief_path = write_publish_brief(task)
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=str(EDGE_PATH),
            headless=False,
        )
        context = browser.new_context(storage_state=str(wechat_video_monitor.get_storage_state_path(account)))
        page = context.new_page()
        urls = [
            "https://channels.weixin.qq.com/platform/post/create",
            "https://channels.weixin.qq.com/platform",
        ]
        open_best_effort(page, urls)
        clicked = ""
        if "post/create" not in page.url.lower():
            clicked = maybe_click_by_text(page, ["发表视频", "发表图文", "发布视频"])
        attach_task_to_page(page, task, brief_path)
        write_debug(
            f"publish_open_wechat_video_{account}.json",
            {
                "platform": "wechat_video",
                "account": account,
                "content_type": content_type,
                "title": title,
                "body": body,
                "asset_paths": task["asset_paths"],
                "task_id": task_id,
                "url": page.url,
                "clicked_entry": clicked,
                "brief_path": str(brief_path),
                "status": "opened",
            },
        )
        print(f"WeChat publish window opened for {account}.")
        page.wait_for_timeout(1000 * 60 * 30)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform", required=True, choices=["xhs", "douyin", "wechat_video"])
    parser.add_argument("--account", required=True)
    parser.add_argument("--content-type", default="video", choices=["video", "image"])
    parser.add_argument("--title", default="")
    parser.add_argument("--body", default="")
    parser.add_argument("--task-id", default="")
    parser.add_argument("--asset", action="append", default=[])
    args = parser.parse_args()

    if not EDGE_PATH.exists():
        raise RuntimeError(f"Edge browser not found: {EDGE_PATH}")

    if args.platform == "xhs":
        open_xhs(args.account, args.content_type, args.title, args.body, args.asset, args.task_id)
    elif args.platform == "douyin":
        open_douyin(args.account, args.content_type, args.title, args.body, args.asset, args.task_id)
    else:
        open_wechat_video(args.account, args.content_type, args.title, args.body, args.asset, args.task_id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
